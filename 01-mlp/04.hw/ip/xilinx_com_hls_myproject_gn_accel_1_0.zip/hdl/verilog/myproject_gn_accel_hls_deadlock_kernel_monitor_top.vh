
wire kernel_monitor_reset;
wire kernel_monitor_clock;
wire kernel_monitor_report;
assign kernel_monitor_reset = ~ap_rst_n;
assign kernel_monitor_clock = ap_clk;
assign kernel_monitor_report = 1'b0;
wire [1:0] axis_block_sigs;
wire [25:0] inst_idle_sigs;
wire [22:0] inst_block_sigs;
wire kernel_block;

assign axis_block_sigs[0] = ~Loop_GN_INPUT_LOOP_proc28_U0.s_axis_in_TDATA_blk_n;
assign axis_block_sigs[1] = ~Loop_GN_OUTPUT_LOOP_proc31_U0.s_axis_out_TDATA_blk_n;

assign inst_idle_sigs[0] = Loop_GN_INPUT_LOOP_proc28_U0.ap_idle;
assign inst_block_sigs[0] = (Loop_GN_INPUT_LOOP_proc28_U0.ap_done & ~Loop_GN_INPUT_LOOP_proc28_U0.ap_continue) | ~Loop_GN_INPUT_LOOP_proc28_U0.in_vec_blk_n;
assign inst_idle_sigs[1] = Block_for_end_proc29_U0.ap_idle;
assign inst_block_sigs[1] = (Block_for_end_proc29_U0.ap_done & ~Block_for_end_proc29_U0.ap_continue) | ~Block_for_end_proc29_U0.in_vec_blk_n | ~Block_for_end_proc29_U0.core_in_blk_n;
assign inst_idle_sigs[2] = myproject_U0.ap_idle;
assign inst_block_sigs[2] = (myproject_U0.ap_done & ~myproject_U0.ap_continue) | ~myproject_U0.dense_array_ap_fixed_161u_array_ap_fixed_24_20_5_3_0_5u_config2_U0.core_in_blk_n | ~myproject_U0.softmax_array_array_ap_fixed_24_20_5_3_0_2u_softmax_config19_U0.grp_softmax_stable_array_array_ap_fixed_24_20_5_3_0_2u_softmax_config19_s_fu_18.core_out_blk_n;
assign inst_idle_sigs[3] = Block_for_end_split_split_proc30_U0.ap_idle;
assign inst_block_sigs[3] = (Block_for_end_split_split_proc30_U0.ap_done & ~Block_for_end_split_split_proc30_U0.ap_continue) | ~Block_for_end_split_split_proc30_U0.core_out_blk_n | ~Block_for_end_split_split_proc30_U0.out_vec_blk_n;
assign inst_idle_sigs[4] = Loop_GN_OUTPUT_LOOP_proc31_U0.ap_idle;
assign inst_block_sigs[4] = (Loop_GN_OUTPUT_LOOP_proc31_U0.ap_done & ~Loop_GN_OUTPUT_LOOP_proc31_U0.ap_continue) | ~Loop_GN_OUTPUT_LOOP_proc31_U0.out_vec_blk_n;
assign inst_idle_sigs[5] = myproject_U0.dense_array_ap_fixed_161u_array_ap_fixed_24_20_5_3_0_5u_config2_U0.ap_idle;
assign inst_block_sigs[5] = (myproject_U0.dense_array_ap_fixed_161u_array_ap_fixed_24_20_5_3_0_5u_config2_U0.ap_done & ~myproject_U0.dense_array_ap_fixed_161u_array_ap_fixed_24_20_5_3_0_5u_config2_U0.ap_continue);
assign inst_idle_sigs[6] = myproject_U0.normalize_array_ap_fixed_5u_array_ap_fixed_24_20_5_3_0_5u_config20_U0.ap_idle;
assign inst_block_sigs[6] = (myproject_U0.normalize_array_ap_fixed_5u_array_ap_fixed_24_20_5_3_0_5u_config20_U0.ap_done & ~myproject_U0.normalize_array_ap_fixed_5u_array_ap_fixed_24_20_5_3_0_5u_config20_U0.ap_continue);
assign inst_idle_sigs[7] = myproject_U0.linear_array_ap_fixed_5u_array_ap_fixed_8_1_4_0_0_5u_linear_config4_U0.ap_idle;
assign inst_block_sigs[7] = (myproject_U0.linear_array_ap_fixed_5u_array_ap_fixed_8_1_4_0_0_5u_linear_config4_U0.ap_done & ~myproject_U0.linear_array_ap_fixed_5u_array_ap_fixed_8_1_4_0_0_5u_linear_config4_U0.ap_continue);
assign inst_idle_sigs[8] = myproject_U0.dense_array_ap_fixed_5u_array_ap_fixed_24_20_5_3_0_4u_config5_U0.ap_idle;
assign inst_block_sigs[8] = (myproject_U0.dense_array_ap_fixed_5u_array_ap_fixed_24_20_5_3_0_4u_config5_U0.ap_done & ~myproject_U0.dense_array_ap_fixed_5u_array_ap_fixed_24_20_5_3_0_4u_config5_U0.ap_continue);
assign inst_idle_sigs[9] = myproject_U0.normalize_array_ap_fixed_4u_array_ap_fixed_24_20_5_3_0_4u_config21_U0.ap_idle;
assign inst_block_sigs[9] = (myproject_U0.normalize_array_ap_fixed_4u_array_ap_fixed_24_20_5_3_0_4u_config21_U0.ap_done & ~myproject_U0.normalize_array_ap_fixed_4u_array_ap_fixed_24_20_5_3_0_4u_config21_U0.ap_continue);
assign inst_idle_sigs[10] = myproject_U0.linear_array_ap_fixed_4u_array_ap_fixed_8_1_4_0_0_4u_linear_config7_U0.ap_idle;
assign inst_block_sigs[10] = (myproject_U0.linear_array_ap_fixed_4u_array_ap_fixed_8_1_4_0_0_4u_linear_config7_U0.ap_done & ~myproject_U0.linear_array_ap_fixed_4u_array_ap_fixed_8_1_4_0_0_4u_linear_config7_U0.ap_continue);
assign inst_idle_sigs[11] = myproject_U0.dense_array_ap_fixed_4u_array_ap_fixed_24_20_5_3_0_4u_config8_U0.ap_idle;
assign inst_block_sigs[11] = (myproject_U0.dense_array_ap_fixed_4u_array_ap_fixed_24_20_5_3_0_4u_config8_U0.ap_done & ~myproject_U0.dense_array_ap_fixed_4u_array_ap_fixed_24_20_5_3_0_4u_config8_U0.ap_continue);
assign inst_idle_sigs[12] = myproject_U0.normalize_array_ap_fixed_4u_array_ap_fixed_24_20_5_3_0_4u_config22_U0.ap_idle;
assign inst_block_sigs[12] = (myproject_U0.normalize_array_ap_fixed_4u_array_ap_fixed_24_20_5_3_0_4u_config22_U0.ap_done & ~myproject_U0.normalize_array_ap_fixed_4u_array_ap_fixed_24_20_5_3_0_4u_config22_U0.ap_continue);
assign inst_idle_sigs[13] = myproject_U0.linear_array_ap_fixed_4u_array_ap_fixed_8_1_4_0_0_4u_linear_config10_U0.ap_idle;
assign inst_block_sigs[13] = (myproject_U0.linear_array_ap_fixed_4u_array_ap_fixed_8_1_4_0_0_4u_linear_config10_U0.ap_done & ~myproject_U0.linear_array_ap_fixed_4u_array_ap_fixed_8_1_4_0_0_4u_linear_config10_U0.ap_continue);
assign inst_idle_sigs[14] = myproject_U0.dense_array_ap_fixed_4u_array_ap_fixed_24_20_5_3_0_5u_config11_U0.ap_idle;
assign inst_block_sigs[14] = (myproject_U0.dense_array_ap_fixed_4u_array_ap_fixed_24_20_5_3_0_5u_config11_U0.ap_done & ~myproject_U0.dense_array_ap_fixed_4u_array_ap_fixed_24_20_5_3_0_5u_config11_U0.ap_continue);
assign inst_idle_sigs[15] = myproject_U0.normalize_array_ap_fixed_5u_array_ap_fixed_24_20_5_3_0_5u_config23_U0.ap_idle;
assign inst_block_sigs[15] = (myproject_U0.normalize_array_ap_fixed_5u_array_ap_fixed_24_20_5_3_0_5u_config23_U0.ap_done & ~myproject_U0.normalize_array_ap_fixed_5u_array_ap_fixed_24_20_5_3_0_5u_config23_U0.ap_continue);
assign inst_idle_sigs[16] = myproject_U0.linear_array_ap_fixed_5u_array_ap_fixed_8_1_4_0_0_5u_linear_config13_U0.ap_idle;
assign inst_block_sigs[16] = (myproject_U0.linear_array_ap_fixed_5u_array_ap_fixed_8_1_4_0_0_5u_linear_config13_U0.ap_done & ~myproject_U0.linear_array_ap_fixed_5u_array_ap_fixed_8_1_4_0_0_5u_linear_config13_U0.ap_continue);
assign inst_idle_sigs[17] = myproject_U0.dense_array_ap_fixed_5u_array_ap_fixed_24_20_5_3_0_3u_config14_U0.ap_idle;
assign inst_block_sigs[17] = (myproject_U0.dense_array_ap_fixed_5u_array_ap_fixed_24_20_5_3_0_3u_config14_U0.ap_done & ~myproject_U0.dense_array_ap_fixed_5u_array_ap_fixed_24_20_5_3_0_3u_config14_U0.ap_continue);
assign inst_idle_sigs[18] = myproject_U0.normalize_array_ap_fixed_3u_array_ap_fixed_24_20_5_3_0_3u_config24_U0.ap_idle;
assign inst_block_sigs[18] = (myproject_U0.normalize_array_ap_fixed_3u_array_ap_fixed_24_20_5_3_0_3u_config24_U0.ap_done & ~myproject_U0.normalize_array_ap_fixed_3u_array_ap_fixed_24_20_5_3_0_3u_config24_U0.ap_continue);
assign inst_idle_sigs[19] = myproject_U0.linear_array_ap_fixed_3u_array_ap_fixed_8_1_4_0_0_3u_linear_config16_U0.ap_idle;
assign inst_block_sigs[19] = (myproject_U0.linear_array_ap_fixed_3u_array_ap_fixed_8_1_4_0_0_3u_linear_config16_U0.ap_done & ~myproject_U0.linear_array_ap_fixed_3u_array_ap_fixed_8_1_4_0_0_3u_linear_config16_U0.ap_continue);
assign inst_idle_sigs[20] = myproject_U0.dense_array_ap_fixed_3u_array_ap_fixed_24_20_5_3_0_2u_config17_U0.ap_idle;
assign inst_block_sigs[20] = (myproject_U0.dense_array_ap_fixed_3u_array_ap_fixed_24_20_5_3_0_2u_config17_U0.ap_done & ~myproject_U0.dense_array_ap_fixed_3u_array_ap_fixed_24_20_5_3_0_2u_config17_U0.ap_continue);
assign inst_idle_sigs[21] = myproject_U0.normalize_array_ap_fixed_2u_array_ap_fixed_24_20_5_3_0_2u_config25_U0.ap_idle;
assign inst_block_sigs[21] = (myproject_U0.normalize_array_ap_fixed_2u_array_ap_fixed_24_20_5_3_0_2u_config25_U0.ap_done & ~myproject_U0.normalize_array_ap_fixed_2u_array_ap_fixed_24_20_5_3_0_2u_config25_U0.ap_continue);
assign inst_idle_sigs[22] = myproject_U0.softmax_array_array_ap_fixed_24_20_5_3_0_2u_softmax_config19_U0.ap_idle;
assign inst_block_sigs[22] = (myproject_U0.softmax_array_array_ap_fixed_24_20_5_3_0_2u_softmax_config19_U0.ap_done & ~myproject_U0.softmax_array_array_ap_fixed_24_20_5_3_0_2u_softmax_config19_U0.ap_continue);

assign inst_idle_sigs[23] = 1'b0;
assign inst_idle_sigs[24] = Loop_GN_INPUT_LOOP_proc28_U0.ap_idle;
assign inst_idle_sigs[25] = Loop_GN_OUTPUT_LOOP_proc31_U0.ap_idle;

myproject_gn_accel_hls_deadlock_idx0_monitor myproject_gn_accel_hls_deadlock_idx0_monitor_U (
    .clock(kernel_monitor_clock),
    .reset(kernel_monitor_reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(kernel_block)
);


always @ (kernel_block or kernel_monitor_reset) begin
    if (kernel_block == 1'b1 && kernel_monitor_reset == 1'b0) begin
        find_kernel_block = 1'b1;
    end
    else begin
        find_kernel_block = 1'b0;
    end
end
