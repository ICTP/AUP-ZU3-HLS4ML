// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xmyproject_gn_accel.h"

extern XMyproject_gn_accel_Config XMyproject_gn_accel_ConfigTable[];

#ifdef SDT
XMyproject_gn_accel_Config *XMyproject_gn_accel_LookupConfig(UINTPTR BaseAddress) {
	XMyproject_gn_accel_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XMyproject_gn_accel_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XMyproject_gn_accel_ConfigTable[Index].Ctrl_BaseAddress == BaseAddress) {
			ConfigPtr = &XMyproject_gn_accel_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XMyproject_gn_accel_Initialize(XMyproject_gn_accel *InstancePtr, UINTPTR BaseAddress) {
	XMyproject_gn_accel_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XMyproject_gn_accel_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XMyproject_gn_accel_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XMyproject_gn_accel_Config *XMyproject_gn_accel_LookupConfig(u16 DeviceId) {
	XMyproject_gn_accel_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XMYPROJECT_GN_ACCEL_NUM_INSTANCES; Index++) {
		if (XMyproject_gn_accel_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XMyproject_gn_accel_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XMyproject_gn_accel_Initialize(XMyproject_gn_accel *InstancePtr, u16 DeviceId) {
	XMyproject_gn_accel_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XMyproject_gn_accel_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XMyproject_gn_accel_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

