
wire kernel_monitor_reset;
wire kernel_monitor_clock;
wire kernel_monitor_report;
assign kernel_monitor_reset = ~ap_rst_n;
assign kernel_monitor_clock = ap_clk;
assign kernel_monitor_report = 1'b0;
wire [1:0] axis_block_sigs;
wire [11:0] inst_idle_sigs;
wire [8:0] inst_block_sigs;
wire kernel_block;

assign axis_block_sigs[0] = ~Loop_READ_INPUT_proc29_U0.s_axis_in_TDATA_blk_n;
assign axis_block_sigs[1] = ~Loop_WRITE_OUTPUT_proc32_U0.s_axis_out_TDATA_blk_n;

assign inst_idle_sigs[0] = Loop_READ_INPUT_proc29_U0.ap_idle;
assign inst_block_sigs[0] = (Loop_READ_INPUT_proc29_U0.ap_done & ~Loop_READ_INPUT_proc29_U0.ap_continue) | ~Loop_READ_INPUT_proc29_U0.token_blk_n;
assign inst_idle_sigs[1] = Block_for_end_proc30_U0.ap_idle;
assign inst_block_sigs[1] = (Block_for_end_proc30_U0.ap_done & ~Block_for_end_proc30_U0.ap_continue) | ~Block_for_end_proc30_U0.token_blk_n | ~Block_for_end_proc30_U0.core_in_blk_n;
assign inst_idle_sigs[2] = myproject_U0.ap_idle;
assign inst_block_sigs[2] = (myproject_U0.ap_done & ~myproject_U0.ap_continue) | ~myproject_U0.embedding_array_ap_fixed_30u_array_ap_fixed_16_10_5_3_0_8u_config2_U0.core_in_blk_n | ~myproject_U0.softmax_array_array_ap_fixed_16_10_5_3_0_100u_softmax_config5_U0.grp_softmax_stable_array_array_ap_fixed_16_10_5_3_0_100u_softmax_config5_s_fu_20.core_out_blk_n;
assign inst_idle_sigs[3] = Block_for_end_split_split_proc31_U0.ap_idle;
assign inst_block_sigs[3] = (Block_for_end_split_split_proc31_U0.ap_done & ~Block_for_end_split_split_proc31_U0.ap_continue) | ~Block_for_end_split_split_proc31_U0.core_out_blk_n | ~Block_for_end_split_split_proc31_U0.out_vec_blk_n;
assign inst_idle_sigs[4] = Loop_WRITE_OUTPUT_proc32_U0.ap_idle;
assign inst_block_sigs[4] = (Loop_WRITE_OUTPUT_proc32_U0.ap_done & ~Loop_WRITE_OUTPUT_proc32_U0.ap_continue) | ~Loop_WRITE_OUTPUT_proc32_U0.out_vec_blk_n;
assign inst_idle_sigs[5] = myproject_U0.embedding_array_ap_fixed_30u_array_ap_fixed_16_10_5_3_0_8u_config2_U0.ap_idle;
assign inst_block_sigs[5] = (myproject_U0.embedding_array_ap_fixed_30u_array_ap_fixed_16_10_5_3_0_8u_config2_U0.ap_done & ~myproject_U0.embedding_array_ap_fixed_30u_array_ap_fixed_16_10_5_3_0_8u_config2_U0.ap_continue);
assign inst_idle_sigs[6] = myproject_U0.gru_stack_array_ap_fixed_8u_array_ap_fixed_16_10_5_3_0_16u_config3_U0.ap_idle;
assign inst_block_sigs[6] = (myproject_U0.gru_stack_array_ap_fixed_8u_array_ap_fixed_16_10_5_3_0_16u_config3_U0.ap_done & ~myproject_U0.gru_stack_array_ap_fixed_8u_array_ap_fixed_16_10_5_3_0_16u_config3_U0.ap_continue);
assign inst_idle_sigs[7] = myproject_U0.dense_array_ap_fixed_16u_array_ap_fixed_16_10_5_3_0_100u_config4_U0.ap_idle;
assign inst_block_sigs[7] = (myproject_U0.dense_array_ap_fixed_16u_array_ap_fixed_16_10_5_3_0_100u_config4_U0.ap_done & ~myproject_U0.dense_array_ap_fixed_16u_array_ap_fixed_16_10_5_3_0_100u_config4_U0.ap_continue);
assign inst_idle_sigs[8] = myproject_U0.softmax_array_array_ap_fixed_16_10_5_3_0_100u_softmax_config5_U0.ap_idle;
assign inst_block_sigs[8] = (myproject_U0.softmax_array_array_ap_fixed_16_10_5_3_0_100u_softmax_config5_U0.ap_done & ~myproject_U0.softmax_array_array_ap_fixed_16_10_5_3_0_100u_softmax_config5_U0.ap_continue);

assign inst_idle_sigs[9] = 1'b0;
assign inst_idle_sigs[10] = Loop_READ_INPUT_proc29_U0.ap_idle;
assign inst_idle_sigs[11] = Loop_WRITE_OUTPUT_proc32_U0.ap_idle;

myproject_embedding_accel_hls_deadlock_idx0_monitor myproject_embedding_accel_hls_deadlock_idx0_monitor_U (
    .clock(kernel_monitor_clock),
    .reset(kernel_monitor_reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(kernel_block)
);


always @ (kernel_block or kernel_monitor_reset) begin
    if (kernel_block == 1'b1 && kernel_monitor_reset == 1'b0) begin
        find_kernel_block = 1'b1;
    end
    else begin
        find_kernel_block = 1'b0;
    end
end
