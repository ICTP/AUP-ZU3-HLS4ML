// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XMYPROJECT_EMBEDDING_ACCEL_H
#define XMYPROJECT_EMBEDDING_ACCEL_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xmyproject_embedding_accel_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Ctrl_BaseAddress;
} XMyproject_embedding_accel_Config;
#endif

typedef struct {
    u64 Ctrl_BaseAddress;
    u32 IsReady;
} XMyproject_embedding_accel;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XMyproject_embedding_accel_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XMyproject_embedding_accel_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XMyproject_embedding_accel_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XMyproject_embedding_accel_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XMyproject_embedding_accel_Initialize(XMyproject_embedding_accel *InstancePtr, UINTPTR BaseAddress);
XMyproject_embedding_accel_Config* XMyproject_embedding_accel_LookupConfig(UINTPTR BaseAddress);
#else
int XMyproject_embedding_accel_Initialize(XMyproject_embedding_accel *InstancePtr, u16 DeviceId);
XMyproject_embedding_accel_Config* XMyproject_embedding_accel_LookupConfig(u16 DeviceId);
#endif
int XMyproject_embedding_accel_CfgInitialize(XMyproject_embedding_accel *InstancePtr, XMyproject_embedding_accel_Config *ConfigPtr);
#else
int XMyproject_embedding_accel_Initialize(XMyproject_embedding_accel *InstancePtr, const char* InstanceName);
int XMyproject_embedding_accel_Release(XMyproject_embedding_accel *InstancePtr);
#endif

void XMyproject_embedding_accel_Start(XMyproject_embedding_accel *InstancePtr);
u32 XMyproject_embedding_accel_IsDone(XMyproject_embedding_accel *InstancePtr);
u32 XMyproject_embedding_accel_IsIdle(XMyproject_embedding_accel *InstancePtr);
u32 XMyproject_embedding_accel_IsReady(XMyproject_embedding_accel *InstancePtr);
void XMyproject_embedding_accel_EnableAutoRestart(XMyproject_embedding_accel *InstancePtr);
void XMyproject_embedding_accel_DisableAutoRestart(XMyproject_embedding_accel *InstancePtr);


void XMyproject_embedding_accel_InterruptGlobalEnable(XMyproject_embedding_accel *InstancePtr);
void XMyproject_embedding_accel_InterruptGlobalDisable(XMyproject_embedding_accel *InstancePtr);
void XMyproject_embedding_accel_InterruptEnable(XMyproject_embedding_accel *InstancePtr, u32 Mask);
void XMyproject_embedding_accel_InterruptDisable(XMyproject_embedding_accel *InstancePtr, u32 Mask);
void XMyproject_embedding_accel_InterruptClear(XMyproject_embedding_accel *InstancePtr, u32 Mask);
u32 XMyproject_embedding_accel_InterruptGetEnabled(XMyproject_embedding_accel *InstancePtr);
u32 XMyproject_embedding_accel_InterruptGetStatus(XMyproject_embedding_accel *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
