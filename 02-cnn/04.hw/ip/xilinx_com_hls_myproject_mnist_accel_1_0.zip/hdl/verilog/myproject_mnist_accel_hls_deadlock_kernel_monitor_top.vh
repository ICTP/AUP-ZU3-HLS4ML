
wire kernel_monitor_reset;
wire kernel_monitor_clock;
wire kernel_monitor_report;
assign kernel_monitor_reset = ~ap_rst_n;
assign kernel_monitor_clock = ap_clk;
assign kernel_monitor_report = 1'b0;
wire [1:0] axis_block_sigs;
wire [22:0] inst_idle_sigs;
wire [19:0] inst_block_sigs;
wire kernel_block;

assign axis_block_sigs[0] = ~Loop_INPUT_LOOP_proc14_U0.s_axis_in_TDATA_blk_n;
assign axis_block_sigs[1] = ~Loop_OUTPUT_LOOP_proc16_U0.s_axis_out_TDATA_blk_n;

assign inst_idle_sigs[0] = Loop_INPUT_LOOP_proc14_U0.ap_idle;
assign inst_block_sigs[0] = (Loop_INPUT_LOOP_proc14_U0.ap_done & ~Loop_INPUT_LOOP_proc14_U0.ap_continue) | ~Loop_INPUT_LOOP_proc14_U0.core_in_blk_n;
assign inst_idle_sigs[1] = myproject_U0.ap_idle;
assign inst_block_sigs[1] = (myproject_U0.ap_done & ~myproject_U0.ap_continue) | ~myproject_U0.zeropad2d_cl_array_array_ap_fixed_16_12_5_3_0_1u_config21_U0.grp_zeropad2d_cl_array_array_ap_fixed_16_12_5_3_0_1u_config21_Pipeline_PadMain_fu_28.core_in_blk_n | ~myproject_U0.softmax_array_array_ap_fixed_16_12_5_3_0_10u_softmax_config16_U0.grp_softmax_argmax_array_array_ap_fixed_16_12_5_3_0_10u_softmax_config16_s_fu_16.core_out_blk_n;
assign inst_idle_sigs[2] = Block_for_end_split_proc15_U0.ap_idle;
assign inst_block_sigs[2] = (Block_for_end_split_proc15_U0.ap_done & ~Block_for_end_split_proc15_U0.ap_continue) | ~Block_for_end_split_proc15_U0.core_out_blk_n | ~Block_for_end_split_proc15_U0.out_vec_blk_n;
assign inst_idle_sigs[3] = Loop_OUTPUT_LOOP_proc16_U0.ap_idle;
assign inst_block_sigs[3] = (Loop_OUTPUT_LOOP_proc16_U0.ap_done & ~Loop_OUTPUT_LOOP_proc16_U0.ap_continue) | ~Loop_OUTPUT_LOOP_proc16_U0.out_vec_blk_n;
assign inst_idle_sigs[4] = myproject_U0.zeropad2d_cl_array_array_ap_fixed_16_12_5_3_0_1u_config21_U0.ap_idle;
assign inst_block_sigs[4] = (myproject_U0.zeropad2d_cl_array_array_ap_fixed_16_12_5_3_0_1u_config21_U0.ap_done & ~myproject_U0.zeropad2d_cl_array_array_ap_fixed_16_12_5_3_0_1u_config21_U0.ap_continue);
assign inst_idle_sigs[5] = myproject_U0.conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_16_12_5_3_0_2u_config2_U0.ap_idle;
assign inst_block_sigs[5] = (myproject_U0.conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_16_12_5_3_0_2u_config2_U0.ap_done & ~myproject_U0.conv_2d_cl_array_ap_fixed_1u_array_ap_fixed_16_12_5_3_0_2u_config2_U0.ap_continue);
assign inst_idle_sigs[6] = myproject_U0.normalize_array_ap_fixed_2u_array_ap_fixed_16_12_5_3_0_2u_config17_U0.ap_idle;
assign inst_block_sigs[6] = (myproject_U0.normalize_array_ap_fixed_2u_array_ap_fixed_16_12_5_3_0_2u_config17_U0.ap_done & ~myproject_U0.normalize_array_ap_fixed_2u_array_ap_fixed_16_12_5_3_0_2u_config17_U0.ap_continue);
assign inst_idle_sigs[7] = myproject_U0.linear_array_ap_fixed_2u_array_ap_fixed_8_5_4_0_0_2u_linear_config4_U0.ap_idle;
assign inst_block_sigs[7] = (myproject_U0.linear_array_ap_fixed_2u_array_ap_fixed_8_5_4_0_0_2u_linear_config4_U0.ap_done & ~myproject_U0.linear_array_ap_fixed_2u_array_ap_fixed_8_5_4_0_0_2u_linear_config4_U0.ap_continue);
assign inst_idle_sigs[8] = myproject_U0.pooling2d_cl_array_ap_fixed_2u_array_ap_fixed_16_12_5_3_0_2u_config5_U0.ap_idle;
assign inst_block_sigs[8] = (myproject_U0.pooling2d_cl_array_ap_fixed_2u_array_ap_fixed_16_12_5_3_0_2u_config5_U0.ap_done & ~myproject_U0.pooling2d_cl_array_ap_fixed_2u_array_ap_fixed_16_12_5_3_0_2u_config5_U0.ap_continue);
assign inst_idle_sigs[9] = myproject_U0.zeropad2d_cl_array_array_ap_fixed_16_12_5_3_0_2u_config22_U0.ap_idle;
assign inst_block_sigs[9] = (myproject_U0.zeropad2d_cl_array_array_ap_fixed_16_12_5_3_0_2u_config22_U0.ap_done & ~myproject_U0.zeropad2d_cl_array_array_ap_fixed_16_12_5_3_0_2u_config22_U0.ap_continue);
assign inst_idle_sigs[10] = myproject_U0.conv_2d_cl_array_ap_fixed_2u_array_ap_fixed_16_12_5_3_0_4u_config6_U0.ap_idle;
assign inst_block_sigs[10] = (myproject_U0.conv_2d_cl_array_ap_fixed_2u_array_ap_fixed_16_12_5_3_0_4u_config6_U0.ap_done & ~myproject_U0.conv_2d_cl_array_ap_fixed_2u_array_ap_fixed_16_12_5_3_0_4u_config6_U0.ap_continue);
assign inst_idle_sigs[11] = myproject_U0.normalize_array_ap_fixed_4u_array_ap_fixed_16_12_5_3_0_4u_config18_U0.ap_idle;
assign inst_block_sigs[11] = (myproject_U0.normalize_array_ap_fixed_4u_array_ap_fixed_16_12_5_3_0_4u_config18_U0.ap_done & ~myproject_U0.normalize_array_ap_fixed_4u_array_ap_fixed_16_12_5_3_0_4u_config18_U0.ap_continue);
assign inst_idle_sigs[12] = myproject_U0.linear_array_ap_fixed_4u_array_ap_fixed_8_5_4_0_0_4u_linear_config8_U0.ap_idle;
assign inst_block_sigs[12] = (myproject_U0.linear_array_ap_fixed_4u_array_ap_fixed_8_5_4_0_0_4u_linear_config8_U0.ap_done & ~myproject_U0.linear_array_ap_fixed_4u_array_ap_fixed_8_5_4_0_0_4u_linear_config8_U0.ap_continue);
assign inst_idle_sigs[13] = myproject_U0.pooling2d_cl_array_ap_fixed_4u_array_ap_fixed_16_12_5_3_0_4u_config9_U0.ap_idle;
assign inst_block_sigs[13] = (myproject_U0.pooling2d_cl_array_ap_fixed_4u_array_ap_fixed_16_12_5_3_0_4u_config9_U0.ap_done & ~myproject_U0.pooling2d_cl_array_ap_fixed_4u_array_ap_fixed_16_12_5_3_0_4u_config9_U0.ap_continue);
assign inst_idle_sigs[14] = myproject_U0.dense_array_ap_fixed_4u_array_ap_fixed_16_12_5_3_0_8u_config11_U0.ap_idle;
assign inst_block_sigs[14] = (myproject_U0.dense_array_ap_fixed_4u_array_ap_fixed_16_12_5_3_0_8u_config11_U0.ap_done & ~myproject_U0.dense_array_ap_fixed_4u_array_ap_fixed_16_12_5_3_0_8u_config11_U0.ap_continue);
assign inst_idle_sigs[15] = myproject_U0.normalize_array_ap_fixed_8u_array_ap_fixed_16_12_5_3_0_8u_config19_U0.ap_idle;
assign inst_block_sigs[15] = (myproject_U0.normalize_array_ap_fixed_8u_array_ap_fixed_16_12_5_3_0_8u_config19_U0.ap_done & ~myproject_U0.normalize_array_ap_fixed_8u_array_ap_fixed_16_12_5_3_0_8u_config19_U0.ap_continue);
assign inst_idle_sigs[16] = myproject_U0.linear_array_ap_fixed_8u_array_ap_fixed_8_5_4_0_0_8u_linear_config13_U0.ap_idle;
assign inst_block_sigs[16] = (myproject_U0.linear_array_ap_fixed_8u_array_ap_fixed_8_5_4_0_0_8u_linear_config13_U0.ap_done & ~myproject_U0.linear_array_ap_fixed_8u_array_ap_fixed_8_5_4_0_0_8u_linear_config13_U0.ap_continue);
assign inst_idle_sigs[17] = myproject_U0.dense_array_ap_fixed_8u_array_ap_fixed_16_12_5_3_0_10u_config14_U0.ap_idle;
assign inst_block_sigs[17] = (myproject_U0.dense_array_ap_fixed_8u_array_ap_fixed_16_12_5_3_0_10u_config14_U0.ap_done & ~myproject_U0.dense_array_ap_fixed_8u_array_ap_fixed_16_12_5_3_0_10u_config14_U0.ap_continue);
assign inst_idle_sigs[18] = myproject_U0.normalize_array_ap_fixed_10u_array_ap_fixed_16_12_5_3_0_10u_config20_U0.ap_idle;
assign inst_block_sigs[18] = (myproject_U0.normalize_array_ap_fixed_10u_array_ap_fixed_16_12_5_3_0_10u_config20_U0.ap_done & ~myproject_U0.normalize_array_ap_fixed_10u_array_ap_fixed_16_12_5_3_0_10u_config20_U0.ap_continue);
assign inst_idle_sigs[19] = myproject_U0.softmax_array_array_ap_fixed_16_12_5_3_0_10u_softmax_config16_U0.ap_idle;
assign inst_block_sigs[19] = (myproject_U0.softmax_array_array_ap_fixed_16_12_5_3_0_10u_softmax_config16_U0.ap_done & ~myproject_U0.softmax_array_array_ap_fixed_16_12_5_3_0_10u_softmax_config16_U0.ap_continue);

assign inst_idle_sigs[20] = 1'b0;
assign inst_idle_sigs[21] = Loop_INPUT_LOOP_proc14_U0.ap_idle;
assign inst_idle_sigs[22] = Loop_OUTPUT_LOOP_proc16_U0.ap_idle;

myproject_mnist_accel_hls_deadlock_idx0_monitor myproject_mnist_accel_hls_deadlock_idx0_monitor_U (
    .clock(kernel_monitor_clock),
    .reset(kernel_monitor_reset),
    .axis_block_sigs(axis_block_sigs),
    .inst_idle_sigs(inst_idle_sigs),
    .inst_block_sigs(inst_block_sigs),
    .block(kernel_block)
);


always @ (kernel_block or kernel_monitor_reset) begin
    if (kernel_block == 1'b1 && kernel_monitor_reset == 1'b0) begin
        find_kernel_block = 1'b1;
    end
    else begin
        find_kernel_block = 1'b0;
    end
end
