// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2024.1 (64-bit)
// Tool Version Limit: 2024.05
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xmyproject_mnist_accel.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XMyproject_mnist_accel_CfgInitialize(XMyproject_mnist_accel *InstancePtr, XMyproject_mnist_accel_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Ctrl_BaseAddress = ConfigPtr->Ctrl_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XMyproject_mnist_accel_Start(XMyproject_mnist_accel *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMyproject_mnist_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XMYPROJECT_MNIST_ACCEL_CTRL_ADDR_AP_CTRL) & 0x80;
    XMyproject_mnist_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XMYPROJECT_MNIST_ACCEL_CTRL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XMyproject_mnist_accel_IsDone(XMyproject_mnist_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMyproject_mnist_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XMYPROJECT_MNIST_ACCEL_CTRL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XMyproject_mnist_accel_IsIdle(XMyproject_mnist_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMyproject_mnist_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XMYPROJECT_MNIST_ACCEL_CTRL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XMyproject_mnist_accel_IsReady(XMyproject_mnist_accel *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XMyproject_mnist_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XMYPROJECT_MNIST_ACCEL_CTRL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XMyproject_mnist_accel_EnableAutoRestart(XMyproject_mnist_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMyproject_mnist_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XMYPROJECT_MNIST_ACCEL_CTRL_ADDR_AP_CTRL, 0x80);
}

void XMyproject_mnist_accel_DisableAutoRestart(XMyproject_mnist_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMyproject_mnist_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XMYPROJECT_MNIST_ACCEL_CTRL_ADDR_AP_CTRL, 0);
}

void XMyproject_mnist_accel_InterruptGlobalEnable(XMyproject_mnist_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMyproject_mnist_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XMYPROJECT_MNIST_ACCEL_CTRL_ADDR_GIE, 1);
}

void XMyproject_mnist_accel_InterruptGlobalDisable(XMyproject_mnist_accel *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMyproject_mnist_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XMYPROJECT_MNIST_ACCEL_CTRL_ADDR_GIE, 0);
}

void XMyproject_mnist_accel_InterruptEnable(XMyproject_mnist_accel *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMyproject_mnist_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XMYPROJECT_MNIST_ACCEL_CTRL_ADDR_IER);
    XMyproject_mnist_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XMYPROJECT_MNIST_ACCEL_CTRL_ADDR_IER, Register | Mask);
}

void XMyproject_mnist_accel_InterruptDisable(XMyproject_mnist_accel *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XMyproject_mnist_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XMYPROJECT_MNIST_ACCEL_CTRL_ADDR_IER);
    XMyproject_mnist_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XMYPROJECT_MNIST_ACCEL_CTRL_ADDR_IER, Register & (~Mask));
}

void XMyproject_mnist_accel_InterruptClear(XMyproject_mnist_accel *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XMyproject_mnist_accel_WriteReg(InstancePtr->Ctrl_BaseAddress, XMYPROJECT_MNIST_ACCEL_CTRL_ADDR_ISR, Mask);
}

u32 XMyproject_mnist_accel_InterruptGetEnabled(XMyproject_mnist_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMyproject_mnist_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XMYPROJECT_MNIST_ACCEL_CTRL_ADDR_IER);
}

u32 XMyproject_mnist_accel_InterruptGetStatus(XMyproject_mnist_accel *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XMyproject_mnist_accel_ReadReg(InstancePtr->Ctrl_BaseAddress, XMYPROJECT_MNIST_ACCEL_CTRL_ADDR_ISR);
}

